#include "float.h"

using namespace std;

// Class constructor
_float_::_float_(void) : data(0) { /* Nothing to do */ }

// Class constructor
_float_::_float_(const float &v) : data(*((unsigned*)&v)) { /* Nothing to do */ }

// Class constructor (private)
_float_::_float_(const unsigned d) : data(d) { /* Nothing to do */ }
   
// Class copy constructor
_float_::_float_(const _float_ &f) : data(f.data) { /* Nothing to do */ }

// Class destructor
_float_::~_float_(void) { /* Nothing to do */ }

// cout << operator
ostream& operator<<(ostream &os, const _float_ &f) { os << *((float*)&f.data); return os; }

// Assignment = operator
_float_& _float_::operator=(const float &v) { data = *((unsigned*)&v); return *this; }

// Assignment = operator
_float_& _float_::operator=(const _float_ &f) { data = f.data; return *this; }

// Unary - operator
_float_ _float_::operator-(void) { return _float_(data ^ (unsigned(1) << (exp_bits + frac_bits))); }





/************************************************************
 * EEE3530 Assignment #3: Floating-point numbers            *
 * Implement the floating-point add, subtract, multiply,    *
 * and divide operators below. The functions should perform *
 * bit-level operations to produce the results.             *
 ************************************************************/

// Add + operator
_float_ _float_::operator+(const _float_ &y) {
    /********************************************************
     * EEE3530 Assignment #3                                *
     * Implement the floating-point add function.           *
     ********************************************************/

    // An example to extract the sign, exponent, and fraction of x (*this).
    // bool x_sign = data >> (exp_bits + frac_bits);
    // int  x_exp  = (data & exp_mask) >> frac_bits;
    // int  x_frac = data & frac_mask;
    
    // An example to extract the sign, exponent, and fraction of y (arg).
    // bool y_sign = y.data >> (exp_bits + frac_bits);
    // int  y_exp  = (y.data & exp_mask) >> frac_bits;
    // int  y_frac = y.data & frac_mask;

    // Put the calculated sign, exponent, and fraction into r.data.
    _float_ r;
    return r;
}

// Subtract - operator
_float_ _float_::operator-(const _float_ &y) {
    /********************************************************
     * EEE3530 Assignment #3                                *
     * Implement the floating-point subtract function.      *
     ********************************************************/

    // Put the calculated sign, exponent, and fraction into r.data.
    _float_ r;
    return r;
}

// Multiply * operator
_float_ _float_::operator*(const _float_ &y) {
    /********************************************************
     * EEE3530 Assignment #3                                *
     * Implement the floating-point multiply function.      *
     ********************************************************/

    // Put the calculated sign, exponent, and fraction into r.data.
    _float_ r;
    return r;
}

// Divide * operator
_float_ _float_::operator/(const _float_ &y) {
    /********************************************************
     * EEE3530 Assignment #3                                *
     * Implement the floating-point divide function.        *
     ********************************************************/

    // Put the calculated sign, exponent, and fraction into r.data.
    _float_ r;
    return r;
}

